@echo off
REM ===== FT-710 Power-Off via CAT (batch version) =====
set RIGCTL="C:\Program Files\Hamlib\bin\rigctl.exe"
set ARGS=-m 1049 -r COM4 -s 38400

echo Powering off FT-710...
%RIGCTL% %ARGS% \set_powerstat 0
echo Sent PS0 (power off).
