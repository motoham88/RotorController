<#  FT-710 Power-Off via CAT  #>

# ---- EDIT THESE (keep in sync with Rig-PowerOn.ps1) ----
$Rigctl = "C:\Program Files\Hamlib\bin\rigctl.exe"
$Model  = 1049          # FT-710
$Port   = "COM4"        # FT-710 "Enhanced" CAT COM port
$Baud   = 38400
# --------------------

Write-Host "Powering off FT-710 on $Port ..."
& $Rigctl -m $Model -r $Port -s $Baud \set_powerstat 0
Write-Host "Sent PS0 (power off)."
