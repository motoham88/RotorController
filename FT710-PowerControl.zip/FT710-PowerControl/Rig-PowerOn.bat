@echo off
REM ===== FT-710 Power-On + Comms Check (batch version) =====
set RIGCTL="C:\Program Files\Hamlib\bin\rigctl.exe"
set ARGS=-m 1049 -r COM4 -s 38400

echo Powering on FT-710...
%RIGCTL% %ARGS% \set_powerstat 1
timeout /t 4 /nobreak >nul

echo.
echo Frequency (Hz):
%RIGCTL% %ARGS% f
echo.
echo Mode:
%RIGCTL% %ARGS% m
echo.
pause
