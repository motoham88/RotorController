FT-710 Power Control helper scripts
===================================

Two flavors, pick one:
  * PowerShell (nicer): Rig-PowerOn.ps1 / Rig-PowerOff.ps1
      - Reads back freq + mode, shows a confirmation box, offers to launch WSJT-X.
  * Batch (simplest):   Rig-PowerOn.bat / Rig-PowerOff.bat
      - Same CAT actions, plain console output.

SETUP
-----
1. Install Hamlib for Windows (4.6.x or newer recommended):
     https://github.com/Hamlib/Hamlib/releases
   Note the path to rigctl.exe (default assumed: C:\Program Files\Hamlib\bin).

2. Edit the config block at the top of whichever script(s) you use:
     $Rigctl / RIGCTL  -> full path to rigctl.exe
     $Model  / 1049    -> FT-710. Verify with:  rigctl -l | findstr /i 710
     $Port   / COM4    -> the FT-710 "Enhanced" CAT COM port (Device Manager).
                          The rig's single USB shows up as TWO COM ports;
                          CAT uses the "Enhanced" one.
     $Baud   / 38400   -> must match the radio menu CAT RATE.
     $Wsjtx            -> path to wsjtx.exe (PowerShell only; "" to skip).

3. (PowerShell) Make a desktop shortcut with this Target so it runs cleanly:
     powershell.exe -ExecutionPolicy Bypass -File "C:\Ham\Rig-PowerOn.ps1"

IMPORTANT — verify before relying on it
----------------------------------------
CAT power-ON only works if the FT-710's USB COM port stays enumerated while
the rig is in soft-off (front-panel off, DC power still applied). Test it:
soft-off the rig and confirm the COM port is still listed in Device Manager.
If it disappears when off, no CAT command can reach the rig to turn it on.

WSJT-X handoff
--------------
The one-shot rigctl calls fully release the COM port when the script exits,
so you can launch WSJT-X right after and let it own the port.
Alternative: run  rigctld -m 1049 -r COM4 -s 38400  as a background server and
point BOTH this applet and WSJT-X at Hamlib NET rigctl (localhost:4532) so
nothing fights over the physical COM port.

Model number 1049 and 38400 baud confirmed from FT-710 Hamlib/remote-control
references; always re-verify the model with `rigctl -l` on the actual PC.
