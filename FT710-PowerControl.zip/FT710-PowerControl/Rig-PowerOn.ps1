<#  FT-710 Power-On + Comms Check
    Turns the rig on via CAT, reads back freq/mode to prove comms,
    then exits (releasing the COM port) so WSJT-X can take over.

    Requires Hamlib for Windows (>= 4.6.x recommended):
      https://github.com/Hamlib/Hamlib/releases
#>

# ---- EDIT THESE ----
$Rigctl = "C:\Program Files\Hamlib\bin\rigctl.exe"
$Model  = 1049          # FT-710 (verify: rigctl -l | findstr /i 710)
$Port   = "COM4"        # FT-710 "Enhanced" CAT COM port (Device Manager)
$Baud   = 38400         # must match radio menu: CAT RATE
$Wsjtx  = "C:\WSJT\wsjtx\bin\wsjtx.exe"   # set to "" to skip the launch prompt
# --------------------

function Rig([string[]]$cmd) { & $Rigctl -m $Model -r $Port -s $Baud @cmd 2>&1 }

Write-Host "Powering on FT-710 on $Port ..."
Rig @('\set_powerstat','1') | Out-Null
Start-Sleep -Seconds 4          # let the rig boot before it will answer

$freq = (Rig @('f')) | Where-Object { $_ -match '^\d+$' }     | Select-Object -First 1
$mode = (Rig @('m')) | Where-Object { $_ -match '^[A-Za-z]' } | Select-Object -First 1

Add-Type -AssemblyName System.Windows.Forms
if ($freq -and [int64]$freq -gt 0) {
    $mhz = "{0:N3}" -f ([double]$freq / 1e6)
    $msg = "FT-710 is ON and talking.`n`nFreq: $mhz MHz`nMode: $mode"
    Write-Host $msg
    if ($Wsjtx -and (Test-Path $Wsjtx)) {
        $r = [System.Windows.Forms.MessageBox]::Show("$msg`n`nLaunch WSJT-X now?",
             "FT-710 Ready", 'YesNo', 'Information')
        if ($r -eq 'Yes') { Start-Process $Wsjtx }
    } else {
        [System.Windows.Forms.MessageBox]::Show($msg, "FT-710 Ready", 'OK', 'Information') | Out-Null
    }
} else {
    $err = "No valid readback from the rig (got: '$freq').`n`nCheck COM port, baud, and that DC power is on."
    Write-Host $err
    [System.Windows.Forms.MessageBox]::Show($err, "FT-710 Comms FAILED", 'OK', 'Error') | Out-Null
}
